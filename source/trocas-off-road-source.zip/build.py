"""Build the single-file game: embeds three.js, the 3D world (world3d.js), the fonts and the Trocas Mamalonas logo into game.src.html.
Run: python3 build.py   ->  writes Trocas-Off-Road.html"""
import base64, os
HERE = os.path.dirname(os.path.abspath(__file__))
b64 = lambda f: base64.b64encode(open(os.path.join(HERE, f), 'rb').read()).decode()
s = open(os.path.join(HERE, 'game.src.html'), encoding='utf-8').read()
fonts = ''.join("@font-face{font-family:'Roboto Slab';font-weight:%d;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2')}" % (w, b64(f))
                for w, f in [(700, 'roboto-slab-latin-700-normal.woff2'), (900, 'roboto-slab-latin-900-normal.woff2')])
s = s.replace('/*FONTS*/', fonts)
# background music, compressed from the WAV to MP3 (96 kbps)
s = s.replace('__MUSIC__', 'data:audio/mpeg;base64,' + b64('music.mp3'))
# the 3D world module goes inside the game, and three.js (the 3D drawing library, MIT license) in its own script tag
s = s.replace('/*WORLD3D*/', open(os.path.join(HERE, 'world3d.js'), encoding='utf-8').read())
s = s.replace('/*THREE*/', open(os.path.join(HERE, 'three.min.js'), encoding='utf-8').read())
s = s.replace('__LOGO_WHITE__', 'data:image/png;base64,' + b64('trocas-logo-white.png')).replace('__LOGO_BLACK__', 'data:image/png;base64,' + b64('trocas-logo-black.png'))
# 1) one self-contained file: open anywhere, embed in a page, or publish as a link
open(os.path.join(HERE, 'Trocas-Off-Road.html'), 'w', encoding='utf-8').write(s.replace('<!--PWA-->', '<link rel="icon" href="data:image/png;base64,' + b64('site/favicon.png') + '">'))
# 2) the website folder (site/): the same game as index.html plus app icons, manifest and offline helper,
#    so phones can add it to the home screen and launch it full screen like an app
pwa = ('<link rel="manifest" href="manifest.webmanifest">\n<link rel="icon" type="image/png" href="favicon.png">\n'
       '<link rel="apple-touch-icon" href="apple-touch-icon.png">\n<meta property="og:image" content="share.jpg">\n'
       '<meta property="og:type" content="website">\n<meta name="twitter:card" content="summary_large_image">')
open(os.path.join(HERE, 'site', 'index.html'), 'w', encoding='utf-8').write(s.replace('<!--PWA-->', pwa))
print('Trocas-Off-Road.html', len(s)//1024, 'KB')
