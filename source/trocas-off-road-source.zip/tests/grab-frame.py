import asyncio,base64,sys,json
from playwright.async_api import async_playwright
async def main(vw,vh,frames,out,extra):
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader'])
        c=await b.new_context(viewport={'width':vw,'height':vh},is_mobile=True,has_touch=True)
        pg=await c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file:///home/claude/race/Trocas-Off-Road.html');await pg.wait_for_timeout(3000)
        url=await pg.evaluate("(()=>{window.__hold=true;const G=__game;G.startRace();G.layout();G.me.human=false;"+extra+"for(let f=0;f<"+str(frames)+";f++)G.step();G.snapCam();G.render3D(1/60,1);return G.R3.domElement.toDataURL('image/png');})()")
        open(out,'wb').write(base64.b64decode(url.split(',')[1]));print('saved',out,'errors',errs[:3]);await b.close()
asyncio.run(main(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),sys.argv[4],sys.argv[5] if len(sys.argv)>5 else ''))
