import asyncio,sys,os,json
from playwright.async_api import async_playwright
SRC='file:///home/claude/race/Trocas-Off-Road.html'
async def run(vp,mobile,steps,out):
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required','--use-gl=swiftshader','--enable-unsafe-swiftshader'])
        c=await b.new_context(viewport=vp,is_mobile=mobile,has_touch=mobile,device_scale_factor=1)
        pg=await c.new_page();errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
        await pg.goto(SRC);await pg.wait_for_timeout(800)
        for st in steps:
            if st.startswith('shot:'):await pg.screenshot(path=f'/home/claude/shots/{st[5:]}.png',timeout=120000);continue
            if st.startswith('wait:'):await pg.wait_for_timeout(int(st[5:]));continue
            if st.startswith('click:'):await pg.click(st[6:]);continue
            if st.startswith('tap:'):await pg.tap(st[4:]);continue
            r=await pg.evaluate(st);print('>',r)
        await pg.evaluate('window.__hold=true');await pg.screenshot(path=f'/home/claude/shots/{out}.png',timeout=120000);print('errors:',errs[:5]);await b.close()
if __name__=='__main__':
    cfg=json.loads(sys.argv[1]);asyncio.run(run(cfg['vp'],cfg.get('mobile',False),cfg['steps'],cfg['out']))
