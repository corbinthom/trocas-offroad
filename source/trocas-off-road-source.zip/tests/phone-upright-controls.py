import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader'])
        c=await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);pg=await c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file:///home/claude/race/Trocas-Off-Road.html');await pg.wait_for_timeout(3000)
        await pg.evaluate("__game.R3.setPixelRatio(0.15);document.getElementById('auto').checked=false;document.getElementById('auto').dispatchEvent(new Event('change'))")
        await pg.tap('#start',timeout=90000);await pg.wait_for_timeout(4000)
        r=await pg.evaluate("""(async()=>{const G=__game,w=ms=>new Promise(r=>setTimeout(r,ms));const pe=(id,type,pid)=>document.getElementById(id).dispatchEvent(new PointerEvent(type,{pointerId:pid,bubbles:true,pointerType:'touch'}));
          const out={state:G.state,padVisible:!document.getElementById('pad').hidden,podVisible:!document.getElementById('steerPod').hidden,logoVisible:getComputedStyle(document.getElementById('padLogo')).display!=='none'};
          pe('bGas','pointerdown',1);await w(1200);out.speedWithGas=+Math.hypot(G.me.vx,G.me.vy).toFixed(2);
          let a0=G.me.ang;pe('bLeft','pointerdown',2);await w(400);pe('bLeft','pointerup',2);out.turnedLeft=+(G.me.ang-a0).toFixed(2);
          a0=G.me.ang;pe('bRight','pointerdown',3);await w(400);pe('bRight','pointerup',3);out.turnedRight=+(G.me.ang-a0).toFixed(2);
          const n0=G.me.nitros;pe('bNitro','pointerdown',4);pe('bNitro','pointerup',4);await w(300);out.nitro=n0+' -> '+G.me.nitros;out.badge=document.getElementById('nitroCount').textContent;
          pe('bGas','pointerup',1);const r=document.getElementById('cv').getBoundingClientRect();out.canvasFillsScreen=r.height===innerHeight&&r.width===innerWidth;return JSON.stringify(out);})()""")
        print(r,'| errors',errs[:3]);await b.close()
asyncio.run(main())
