import asyncio,base64,sys,io
from playwright.async_api import async_playwright
from PIL import Image
async def main(vw,vh,frames,out):
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader'])
        c=await b.new_context(viewport={'width':vw,'height':vh},is_mobile=True,has_touch=True)
        pg=await c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file:///home/claude/race/Trocas-Off-Road.html');await pg.wait_for_timeout(3000)
        url=await pg.evaluate("(()=>{window.__hold=true;const G=__game;G.startRace();G.layout();G.me.human=false;for(let f=0;f<"+str(frames)+";f++)G.step();G.me.human=true;G.snapCam();G.render3D(1/60,1);const u=G.R3.domElement.toDataURL('image/png');document.getElementById('cv').style.visibility='hidden';document.documentElement.style.background=document.body.style.background='transparent';return u;})()")
        await pg.evaluate("(()=>{const G=__game;document.getElementById('nitroCount').textContent=G.me.nitros;})()")
        await pg.wait_for_timeout(400)
        ui=Image.open(io.BytesIO(await pg.screenshot(omit_background=True))).convert('RGBA')
        fr=Image.open(io.BytesIO(base64.b64decode(url.split(',')[1]))).convert('RGBA').resize(ui.size)
        fr.alpha_composite(ui);fr.convert('RGB').save(out);print('saved',out,'errors',errs[:3]);await b.close()
asyncio.run(main(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),sys.argv[4]))
