import asyncio
from playwright.async_api import async_playwright
SRC='file:///home/claude/race/Trocas-Off-Road.html'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader'])
        # desktop keyboard
        pg=await b.new_page(viewport={'width':1280,'height':800});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(SRC);await pg.wait_for_timeout(2500);await pg.evaluate('__game.R3.setPixelRatio(0.15);__game.layout()');await pg.keyboard.press('Enter');await pg.wait_for_timeout(3600)
        s0=await pg.evaluate("__game.state")
        await pg.keyboard.down('ArrowUp');await pg.wait_for_timeout(1500)
        sp=await pg.evaluate("Math.hypot(__game.me.vx,__game.me.vy).toFixed(2)")
        a0=await pg.evaluate("__game.me.ang");await pg.keyboard.down('ArrowRight');await pg.wait_for_timeout(500);await pg.keyboard.up('ArrowRight')
        a1=await pg.evaluate("__game.me.ang");n0=await pg.evaluate("__game.me.nitros")
        await pg.keyboard.press('Space');await pg.wait_for_timeout(100);n1=await pg.evaluate("[__game.me.nitros,__game.me.nitroT>0]")
        await pg.keyboard.up('ArrowUp');await pg.keyboard.press('KeyP');paused=await pg.evaluate("!document.getElementById('pauseOv').hidden")
        await pg.click('#resume',timeout=90000);
        # run the rest of the race with the computer driving, then check results and race again
        r=await pg.evaluate("(()=>{const G=__game;G.me.human=false;for(let f=0;f<20000&&G.state!=='done';f++)G.step();return G.state+' results shown '+!document.getElementById('results').hidden+' '+document.getElementById('rPlace').textContent+' rows '+document.querySelectorAll('#rTable tr').length;})()")
        await pg.click('#again',timeout=90000);await pg.wait_for_timeout(300);again=await pg.evaluate("__game.state+' laps done '+__game.me.lap")
        print('desktop: state after countdown',s0,'| speed with Up',sp,'| turned right',round(a1-a0,2),'| nitro',n0,'->',n1,'| paused',paused,'|',r,'| race again ->',again,'| errors',errs)
        # sideways phone: drag wheel and hold gas
        c=await b.new_context(viewport={'width':844,'height':390},is_mobile=True,has_touch=True);pm=await c.new_page();e2=[];pm.on('pageerror',lambda e:e2.append(str(e)))
        await pm.goto(SRC);await pm.wait_for_timeout(2500);await pm.evaluate('__game.R3.setPixelRatio(0.15);__game.layout()');await pm.evaluate("document.getElementById('auto').checked=false;document.getElementById('auto').dispatchEvent(new Event('change'))")
        await pm.tap('#start',timeout=90000);await pm.wait_for_timeout(3600)
        js="""(async()=>{const G=__game,z=document.getElementById('wheelZone'),gas=document.getElementById('bGas');
          const pe=(el,type,x,id)=>el.dispatchEvent(new PointerEvent(type,{pointerId:id,clientX:x,clientY:300,bubbles:true,pointerType:'touch',isPrimary:id===1}));
          const sp0=Math.hypot(G.me.vx,G.me.vy);pe(gas,'pointerdown',790,2);await new Promise(r=>setTimeout(r,1200));const sp1=Math.hypot(G.me.vx,G.me.vy);
          const a0=G.me.ang;pe(z,'pointerdown',100,1);pe(z,'pointermove',60,1);await new Promise(r=>setTimeout(r,400));const st=G.me.input.steer,a1=G.me.ang;pe(z,'pointerup',60,1);pe(gas,'pointerup',790,2);
          return 'speed '+sp0.toFixed(2)+' -> '+sp1.toFixed(2)+' with Gas held | wheel steer '+st.toFixed(2)+' turned '+(a1-a0).toFixed(2)+' | wheel visible '+!document.getElementById('wheel').hidden;})()"""
        print('phone sideways:',await pm.evaluate(js),'| errors',e2)
        await b.close()
asyncio.run(main())
