/* =========================================================================
   3D world (three.js). The physics is unchanged and still works in the flat
   960 x 600 world. Here world x becomes three.js x, world y becomes three.js z,
   and height (t.z) becomes three.js y. One unit is the same everywhere.
   ========================================================================= */
if(THREE.ColorManagement)THREE.ColorManagement.legacyMode=false; // paint colors are normal screen colors
const MK=1024/W;
const marks=document.createElement('canvas');marks.width=1024;marks.height=640;const mk=marks.getContext('2d');
const logoB=new Image(),logoW=new Image();let logosReady=0;
document.documentElement.style.setProperty('--logo',`url("${LOGO_W}")`);
const isTouch=matchMedia('(pointer:coarse)').matches;
let R3=null,scene=null,cam=null,sun=null,groundMat=null,marksTex=null,pts=null,envTex=null,arrow=null,flagman=null;
const pickupMeshes=new Map(),coinMeshes=new Map();let _coinGeo=null,_coinMats=null;
function coinGeo(){return _coinGeo||(_coinGeo=new THREE.CylinderGeometry(10.5,10.5,2,36));}
function coinMats(){if(_coinMats)return _coinMats;const[c,g]=mkCanvas(256,256);
  const gr=g.createRadialGradient(100,90,10,128,128,128);gr.addColorStop(0,'#fff4b8');gr.addColorStop(.55,'#f0c040');gr.addColorStop(1,'#9a6a10');g.fillStyle=gr;g.beginPath();g.arc(128,128,128,0,TAU);g.fill();
  g.lineWidth=12;g.strokeStyle='#b8861c';g.beginPath();g.arc(128,128,116,0,TAU);g.stroke();
  if(logosReady===2){const w=206,h=w*logoB.height/logoB.width;g.globalAlpha=.9;g.drawImage(logoB,128-w/2,132-h/2,w,h);g.globalAlpha=1;}
  const face=std({map:tex(c),metalness:.75,roughness:.28,emissive:'#5a3c00',emissiveIntensity:.35}),edge=std({color:'#e0aa30',metalness:.9,roughness:.25,emissive:'#4a3000',emissiveIntensity:.3});
  return _coinMats=[edge,face,face];}
const COLORS=[['Red','#d42a24'],['Blue','#2a62d8'],['Yellow','#f2c018'],['Silver','#b8bec8'],['Green','#2e9e46'],['Pink','#ec6fa8'],['Orange','#f07a1a'],['Black','#2a2c30']];
const MODELS=[['truck','Stadium Truck'],['jeep','Jeep'],['muscle','Muscle Car'],['classic','Classic']];

function strokePath(g,off){g.beginPath();for(let i=0;i<=T.n;i++){const j=i%T.n,x=T.x[j]+T.nx[j]*off,y=T.y[j]+T.ny[j]*off;i?g.lineTo(x,y):g.moveTo(x,y);}g.closePath();}
function tex(c,repeat){const t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;if(repeat){t.wrapS=t.wrapT=THREE.RepeatWrapping;}if(R3)t.anisotropy=Math.min(8,R3.capabilities.getMaxAnisotropy());return t;}
function mkCanvas(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return[c,c.getContext('2d')];}
const std=(o)=>new THREE.MeshStandardMaterial(o);
// the Trocas Mamalonas logo as textures (white and black), and a banner painter for signs
let _logoTex=null;
function logoTex(black){if(!_logoTex)_logoTex={};const k=black?'b':'w';if(_logoTex[k])return _logoTex[k];const im=black?logoB:logoW;
  const[c,g]=mkCanvas(512,Math.round(512*im.height/im.width)||233);if(logosReady===2)g.drawImage(im,0,0,c.width,c.height);return _logoTex[k]=tex(c);}
function bannerTex(w,h,copies,bg='#121010'){const[c,g]=mkCanvas(w,h);g.fillStyle=bg;g.fillRect(0,0,w,h);
  g.fillStyle='#d42a24';g.fillRect(0,h-h*.09,w,h*.09);g.fillStyle='#f2efe8';for(let x=0;x<w;x+=h*.18)g.fillRect(x,h-h*.09,h*.09,h*.09);g.fillRect(0,0,w,h*.04);
  if(logosReady===2){const lh=h*.74,lw=lh*logoW.width/logoW.height,gap=(w-copies*lw)/copies;for(let k=0;k<copies;k++)g.drawImage(logoW,gap/2+k*(lw+gap),h*.07,lw,lh);}
  return tex(c);}
const shadowy=m=>{m.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});return m;};

/* ---------- the ground: one big painted picture of the arena floor ---------- */
function paintGround(){
  const GS=2048/W,[c,g]=mkCanvas(2048,1280);g.scale(GS,GS);
  g.fillStyle='#a8703f';g.fillRect(0,0,W,H);
  g.strokeStyle='rgba(110,64,30,.16)';g.lineWidth=1.2;for(let d=-H;d<W;d+=6){g.beginPath();g.moveTo(d,H);g.lineTo(d+H,0);g.stroke();}
  g.lineJoin=g.lineCap='round';
  strokePath(g,0);g.strokeStyle='#7a4624';g.lineWidth=HW*2+4;g.stroke();
  for(const o of [-30,-22,-13,-5,5,13,22,30]){strokePath(g,o);g.strokeStyle=`rgba(60,30,12,${.12+hash(o,3)*.12})`;g.lineWidth=1.5+hash(o,7)*2;g.stroke();}
  for(const o of [-26,-9,9,26]){strokePath(g,o);g.strokeStyle='rgba(230,180,120,.08)';g.lineWidth=3;g.stroke();}
  for(const z of FEAT.mud){const gr=g.createRadialGradient(z.x,z.y,1,z.x,z.y,z.r*1.2);gr.addColorStop(0,'#3a2210');gr.addColorStop(.75,'#4e2e16');gr.addColorStop(1,'rgba(78,46,22,0)');g.fillStyle=gr;g.beginPath();g.ellipse(z.x,z.y,z.r*1.25,z.r,0,0,TAU);g.fill();
    g.fillStyle='rgba(255,240,220,.12)';for(let k=0;k<6;k++){g.beginPath();g.ellipse(z.x+(hash(k,z.x)-.5)*z.r,z.y+(hash(z.y,k)-.5)*z.r*.8,4,1.5,.3,0,TAU);g.fill();}}
  for(const z of FEAT.water){const gr=g.createRadialGradient(z.x,z.y,z.r*.6,z.x,z.y,z.r*1.35);gr.addColorStop(0,'#3a2412');gr.addColorStop(1,'rgba(70,40,18,0)');g.fillStyle=gr;g.beginPath();g.ellipse(z.x,z.y,z.r*1.4,z.r*1.15,0,0,TAU);g.fill();}
  {const i=0,sq=6,cols=Math.round((HW*2)/sq);for(let r=0;r<3;r++)for(let k=0;k<cols;k++){const lat=-HW+k*sq+sq/2,al=(r-1)*sq;
    g.save();g.translate(T.x[i]+T.nx[i]*lat+T.tx[i]*al,T.y[i]+T.ny[i]*lat+T.ty[i]*al);g.rotate(Math.atan2(T.ty[i],T.tx[i]));g.fillStyle=(r+k)%2?'#151515':'#efebe2';g.fillRect(-sq/2,-sq/2,sq,sq);g.restore();}}
  if(logosReady===2){g.globalAlpha=.78;const w=180,h=w*logoB.height/logoB.width;g.drawImage(logoB,620-w/2,433-h/2,w,h);g.globalAlpha=1;
    // a big logo painted on the dirt before each ramp, turned so it always reads upright for the camera
    for(const f of FEAT.jumps){const i=wrapI(f-15);let a=Math.atan2(T.ty[i],T.tx[i]);if(Math.cos(a)<0)a+=Math.PI;
      g.save();g.translate(T.x[i],T.y[i]);g.rotate(a);g.globalAlpha=.6;const lw=76,lh=lw*logoB.height/logoB.width;g.drawImage(logoB,-lw/2,-lh/2,lw,lh);g.restore();}
    g.globalAlpha=1;}
  g.setTransform(1,0,0,1,0,0);const im=g.getImageData(0,0,2048,1280),d=im.data;
  for(let p=0,y=0;y<1280;y++)for(let x=0;x<2048;x++,p+=4){const n=(hash(x*.7,y*.7)-.5)*22+(hash(x>>3,y>>3)-.5)*10;d[p]=clamp(d[p]+n,0,255);d[p+1]=clamp(d[p+1]+n*.85,0,255);d[p+2]=clamp(d[p+2]+n*.65,0,255);}
  g.putImageData(im,0,0);return c;
}
function dirtTile(){const[c,g]=mkCanvas(256,256);g.fillStyle='#a8743f';g.fillRect(0,0,256,256);
  for(let k=0;k<2600;k++){const x=hash(k,1)*256,y=hash(k,2)*256;g.fillStyle=hash(k,3)<.5?'rgba(80,46,18,.25)':'rgba(230,190,140,.18)';g.fillRect(x,y,1+hash(k,4)*3,1+hash(k,5)*2);}return c;}

/* ---------- geometry helpers ---------- */
function ribbon(offs,hts,cols,uvMode,stripe){
  // a strip that follows the track on one side, made of rows at the given sideways offsets and heights
  const n=T.n,m=offs.length,pos=[],uv=[],col=[],idx=[];let dist=0;
  for(let i=0;i<=n;i++){const j=i%n;if(i)dist+=Math.hypot(T.x[j]-T.x[(j-1+n)%n],T.y[j]-T.y[(j-1+n)%n]);
    for(let k=0;k<m;k++){const x=T.x[j]+T.nx[j]*offs[k],y=T.y[j]+T.ny[j]*offs[k];pos.push(x,hts[k],y);
      if(uvMode==='world')uv.push(x/W,1-y/H);else uv.push(dist/stripe,k/(m-1));const c=cols?cols[k]:1;col.push(c,c,c);}}
  for(let i=0;i<n;i++)for(let k=0;k<m-1;k++){const a=i*m+k,b=(i+1)*m+k;idx.push(a,b,a+1,b,b+1,a+1);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));
  geo.setAttribute('color',new THREE.Float32BufferAttribute(col,3));geo.setIndex(idx);geo.computeVertexNormals();return geo;}
function taper(w,h,d,top,shift=0){const g=new THREE.BoxGeometry(w,h,d),p=g.attributes.position;
  for(let i=0;i<p.count;i++)if(p.getY(i)>0){p.setX(i,p.getX(i)*top+shift);p.setZ(i,p.getZ(i)*(.5+top*.5));}g.computeVertexNormals();return g;}

/* ---------- vehicles: toy-style models built from simple shapes ---------- */
const MAT={};
function mats(){if(MAT.tire)return MAT;
  MAT.tire=std({color:'#1a1816',roughness:.92});MAT.rim=std({color:'#d8d8dc',metalness:.85,roughness:.25});MAT.chrome=std({color:'#e8e8ec',metalness:.95,roughness:.18});
  MAT.glass=std({color:'#1c2834',metalness:.4,roughness:.08});MAT.dark=std({color:'#262422',roughness:.7});MAT.light=std({color:'#fff6d0',emissive:'#fff2b0',emissiveIntensity:.8});
  MAT.tail=std({color:'#ff2a1a',emissive:'#ff2010',emissiveIntensity:.6});MAT.white=std({color:'#f2f0ea',roughness:.5});MAT.seat=std({color:'#3a2a20',roughness:.8});
  MAT.flame=new THREE.MeshBasicMaterial({color:'#3a8cff',transparent:true,opacity:.75,blending:THREE.AdditiveBlending,depthWrite:false});return MAT;}
function box(w,h,d,m,x,y,z,parent){const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);b.position.set(x,y,z);parent.add(b);return b;}
function wheel(r,wd,x,z,parent,front,list){const piv=new THREE.Group();piv.position.set(x,r,z);parent.add(piv);
  const spin=new THREE.Group();piv.add(spin);
  const t=new THREE.Mesh(new THREE.CylinderGeometry(r,r,wd,18),MAT.tire);t.rotation.x=Math.PI/2;spin.add(t);
  for(let k=0;k<6;k++){const lug=new THREE.Mesh(new THREE.BoxGeometry(r*.35,r*2.04,wd*1.02),MAT.tire);lug.rotation.z=k/6*Math.PI;spin.add(lug);}
  const rim=new THREE.Mesh(new THREE.CylinderGeometry(r*.55,r*.55,wd*1.06,12),MAT.rim);rim.rotation.x=Math.PI/2;spin.add(rim);
  list.push({piv,spin,front,r,z0:z});}
function buildVehicle(model,hex){
  mats();const paint=std({color:hex,metalness:.15,roughness:.38,envMapIntensity:.55}),accent=std({color:new THREE.Color(hex).multiplyScalar(.55),metalness:.3,roughness:.5});
  const root=new THREE.Group(),body=new THREE.Group(),wheels=[];root.add(body);
  if(model==='truck'){const r=5.4,y0=r+2.2;
    for(const [x,f] of [[9.5,1],[-9.5,0]])for(const z of [-9,9])wheel(r,4.4,x,z,root,f,wheels);
    box(24,2.2,11,MAT.dark,0,y0-1,0,body);
    box(29,4.6,15,paint,0,y0+2,0,body);box(10,1.2,15.4,accent,9,y0+.2,0,body);
    const cab=new THREE.Mesh(new THREE.BoxGeometry(9,6,13.6),[MAT.glass,MAT.glass,paint,paint,MAT.glass,MAT.glass]);cab.position.set(-.5,y0+7.3,0);body.add(cab);
    box(9.6,1,14.2,paint,-.5,y0+10.6,0,body);
    for(const z of [-7,7])box(12,2.4,1,paint,-9,y0+5.4,z,body);box(1,2.4,15,paint,-14.6,y0+5.4,0,body);box(11,.4,12.6,MAT.dark,-9,y0+4.4,0,body);
    for(const z of [-6.6,6.6])box(1,6,1,MAT.white,-5.6,y0+7.4,z,body);box(1,1,14,MAT.white,-5.6,y0+10.4,0,body);
    for(const z of [-4,-1.4,1.4,4])box(1,1,1.6,MAT.light,-.5,y0+11.4,z,body);
    box(1.2,2.4,16,MAT.chrome,15,y0+1,0,body);for(const z of [-5,5])box(.6,1.6,2.6,MAT.light,14.6,y0+3,z,body);for(const z of [-5.5,5.5])box(.6,1.4,2.4,MAT.tail,-15.1,y0+3,z,body);
  }else if(model==='jeep'){const r=5,y0=r+1.8;
    for(const [x,f] of [[8.6,1],[-8.6,0]])for(const z of [-8.4,8.4])wheel(r,4,x,z,root,f,wheels);
    box(25,5.4,14,paint,0,y0+2.2,0,body);box(8,1.4,14.4,paint,8.6,y0+5.2,0,body);
    box(1,5,13.6,MAT.glass,4.4,y0+7.6,0,body);box(1.2,1,14,paint,4.4,y0+10.2,0,body);
    for(const z of [-4,4])box(4,3.6,4.4,MAT.seat,-1.5,y0+6.2,z,body);
    for(const z of [-6.6,6.6])box(1,6.4,1,MAT.dark,-6,y0+7.4,z,body);box(1,1,14.2,MAT.dark,-6,y0+10.6,0,body);for(const z of [-6.6,6.6])box(10.6,1,1,MAT.dark,-.8,y0+10.6,z,body);
    const sp=new THREE.Mesh(new THREE.CylinderGeometry(4.2,4.2,2.6,16),MAT.tire);sp.rotation.z=Math.PI/2;sp.position.set(-13.8,y0+4.4,0);body.add(sp);
    box(1.4,2.6,15,MAT.dark,12.8,y0+.6,0,body);for(const z of [-4.6,4.6]){const l=new THREE.Mesh(new THREE.CylinderGeometry(1.3,1.3,.8,12),MAT.light);l.rotation.z=Math.PI/2;l.position.set(12.6,y0+3.8,z);body.add(l);}
    for(const z of [-5.5,5.5])box(.6,1.4,2,MAT.tail,-12.6,y0+3,z,body);
  }else if(model==='muscle'){const r=4.2,y0=r+.6;
    for(const [x,f] of [[10.4,1],[-10,0]])for(const z of [-8,8])wheel(x<0?r*1.08:r,x<0?4.6:3.8,x,z,root,f,wheels);
    box(32,4.4,15,paint,0,y0+2,0,body);
    const cab=new THREE.Mesh(taper(13,5,13.4,.62,-.8),[MAT.glass,MAT.glass,paint,paint,MAT.glass,MAT.glass]);cab.position.set(-2.4,y0+6.6,0);body.add(cab);
    box(8,.3,13.4,paint,-3.2,y0+9.15,0,body);
    for(const z of [-2,2]){box(31.6,.3,1.6,MAT.white,0,y0+4.3,z,body);box(7.8,.3,1.6,MAT.white,-3.2,y0+9.35,z,body);}
    box(2.6,.6,14.6,accent,-15,y0+6.4,0,body);for(const z of [-6,6])box(1,2.2,1,accent,-15,y0+5,z,body);
    const sc=box(6,1.4,5,MAT.dark,7.6,y0+4.8,0,body);sc.material=accent;
    box(1,1.6,15.4,MAT.chrome,16,y0+1.2,0,body);for(const z of [-5,5])box(.6,1.4,2.6,MAT.light,15.8,y0+2.8,z,body);for(const z of [-5,5])box(.6,1.2,3,MAT.tail,-16.1,y0+2.8,z,body);
  }else{const r=4,y0=r+.8;
    for(const [x,f] of [[10.6,1],[-10.4,0]])for(const z of [-7.6,7.6])wheel(r,3.6,x,z,root,f,wheels);
    box(34,4.8,15,paint,0,y0+2.2,0,body);box(34.4,1,15.4,MAT.chrome,0,y0+.2,0,body);
    const cab=new THREE.Mesh(taper(14,5,13.6,.72,-.6),[MAT.glass,MAT.glass,MAT.white,MAT.white,MAT.glass,MAT.glass]);cab.position.set(-1.6,y0+7,0);body.add(cab);
    for(const z of [-6.8,6.8]){const fin=new THREE.Mesh(taper(9,3.2,1.2,.3,-3),paint);fin.position.set(-12.6,y0+5.6,z);body.add(fin);}
    box(1.2,2,16,MAT.chrome,17.4,y0+1.6,0,body);box(1.2,2,16,MAT.chrome,-17.4,y0+1.6,0,body);
    for(const z of [-5.4,5.4]){const l=new THREE.Mesh(new THREE.CylinderGeometry(1.2,1.2,.8,12),MAT.light);l.rotation.z=Math.PI/2;l.position.set(17,y0+3.4,z);body.add(l);}
    for(const z of [-6.4,6.4])box(1.4,1.4,1,MAT.tail,-17,y0+4.6,z,body);
    box(32,.4,.6,MAT.chrome,0,y0+2.6,7.6,body);box(32,.4,.6,MAT.chrome,0,y0+2.6,-7.6,body);
  }
  const flame=new THREE.Mesh(new THREE.ConeGeometry(2.2,10,10),MAT.flame);flame.rotation.z=Math.PI/2;flame.position.set(-21,4.5,0);flame.visible=false;root.add(flame);
  // Trocas logo painted on the hood (on the trunk of the muscle car, where the hood scoop is)
  {const light=['#f2c018','#b8bec8','#ec6fa8','#f07a1a'].includes(hex),spot={truck:[10.2,5.4+2.2+4.36],jeep:[8.6,5+1.8+5.96],muscle:[-11.6,4.2+.6+4.48],classic:[11,4+.8+4.66]}[model];
   const dm=std({map:logoTex(light),transparent:true,depthWrite:false,roughness:.5,polygonOffset:true,polygonOffsetFactor:-2});
   const decal=new THREE.Mesh(new THREE.PlaneGeometry(13.4,13.4/2.2),dm);decal.rotation.set(-Math.PI/2,0,Math.PI/2);decal.position.set(spot[0],spot[1],0);body.add(decal);root.userData.decal=decal;}
  shadowy(root);flame.castShadow=false;
  // twin tailpipes with fire, shown once the truck turns gold
  const bb=new THREE.Box3().setFromObject(body),rear=bb.min.x,fire=new THREE.Group();
  for(const z of [-4,4]){const pipe=new THREE.Mesh(new THREE.CylinderGeometry(1,1,4,10),MAT.chrome);pipe.rotation.z=Math.PI/2;pipe.position.set(rear-1,bb.min.y+2.6,z);fire.add(pipe);
    const outer=new THREE.Mesh(new THREE.ConeGeometry(2,9,10),new THREE.MeshBasicMaterial({color:'#ff6a14',transparent:true,opacity:.85,blending:THREE.AdditiveBlending,depthWrite:false}));
    outer.rotation.z=Math.PI/2;outer.position.set(rear-7.5,bb.min.y+2.6,z);fire.add(outer);
    const inner=new THREE.Mesh(new THREE.ConeGeometry(1,5,8),new THREE.MeshBasicMaterial({color:'#fff2a0',transparent:true,opacity:.95,blending:THREE.AdditiveBlending,depthWrite:false}));
    inner.rotation.z=Math.PI/2;inner.position.set(rear-5,bb.min.y+2.6,z);fire.add(inner);}
  fire.visible=false;root.add(fire);
  return{root,body,wheels,flame,paint,accent,fire,level:0,decal:root.userData.decal};
}

/* ---------- the arena around the track ---------- */
function buildArena(){
  const gTex=tex(paintGround());gTex.anisotropy=Math.min(8,R3.capabilities.getMaxAnisotropy());
  groundMat=std({map:gTex,roughness:.95,vertexColors:true,side:THREE.DoubleSide});
  // main floor
  {const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute([0,0,0,W,0,0,0,0,H,W,0,H],3));
   geo.setAttribute('uv',new THREE.Float32BufferAttribute([0,1,1,1,0,0,1,0],2));geo.setAttribute('normal',new THREE.Float32BufferAttribute([0,1,0,0,1,0,0,1,0,0,1,0],3));
   geo.setAttribute('color',new THREE.Float32BufferAttribute([1,1,1,1,1,1,1,1,1,1,1,1],3));geo.setIndex([0,2,1,2,3,1]);
   const m=new THREE.Mesh(geo,groundMat);m.receiveShadow=true;scene.add(m);}
  // dirt all around the arena
  {const t=tex(dirtTile(),true);t.repeat.set(30,30);const m=new THREE.Mesh(new THREE.PlaneGeometry(6000,6000),std({map:t,roughness:1}));m.rotation.x=-Math.PI/2;m.position.set(W/2,-.4,H/2);m.receiveShadow=true;scene.add(m);}
  // skid marks layer
  marksTex=new THREE.CanvasTexture(marks);
  {const geo=new THREE.PlaneGeometry(W,H);const m=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({map:marksTex,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));m.rotation.x=-Math.PI/2;m.position.set(W/2,.08,H/2);scene.add(m);}
  // raised earth banks on both sides, with red and white curbs at the track edge
  const OFF=[HW+.5,HW+3.5,HW+7,HW+10,HW+13.5,HW+19],HT=[0,4.2,8,9.2,7.5,0],SH=[.78,.86,1.02,1.12,1,.92];
  for(const s of [-1,1]){const geo=ribbon(OFF.map(o=>o*s),HT,SH,'world');if(s<0){const ix=geo.index.array;for(let k=0;k<ix.length;k+=3){const a=ix[k];ix[k]=ix[k+1];ix[k+1]=a;}geo.computeVertexNormals();}
    const m=new THREE.Mesh(geo,groundMat);m.receiveShadow=true;m.castShadow=true;scene.add(m);}
  {const[c,g]=mkCanvas(64,16);g.fillStyle='#d42a24';g.fillRect(0,0,32,16);g.fillStyle='#f2efe8';g.fillRect(32,0,32,16);const t=tex(c,true);
   for(const s of [-1,1]){const geo=ribbon([(HW-2.6)*s,(HW+.6)*s],[.25,.9],null,'dist',14);if(s<0){const ix=geo.index.array;for(let k=0;k<ix.length;k+=3){const a=ix[k];ix[k]=ix[k+1];ix[k+1]=a;}geo.computeVertexNormals();}
     const m=new THREE.Mesh(geo,std({map:t,roughness:.6,side:THREE.DoubleSide}));m.receiveShadow=true;scene.add(m);}}
  // jump ramps: a slope up to a lip, then a short drop
  {const[c,g]=mkCanvas(128,256);g.fillStyle='#b07644';g.fillRect(0,0,128,256);for(let k=0;k<900;k++){g.fillStyle=hash(k,9)<.5?'rgba(90,50,20,.3)':'rgba(255,220,170,.25)';g.fillRect(hash(k,1)*128,hash(k,2)*256,2,2);}
   // the logo reads across the ramp; a bright lip at the top edge
   if(logosReady===2){g.save();g.translate(60,128);g.rotate(-Math.PI/2);const lw=226,lh=lw*logoB.height/logoB.width;g.globalAlpha=.92;g.drawImage(logoB,-lw/2,-lh/2,lw,lh);g.restore();}
   g.fillStyle='#fff1d6';g.fillRect(118,0,10,256);const rt=tex(c);const rm=std({map:rt,roughness:.9,side:THREE.DoubleSide}),side=std({color:'#8a5228',roughness:1});
   for(const f of FEAT.jumps){const L=FACE*6,h=7,w=HW-1,B=9;const geo=new THREE.BufferGeometry();
     const P=[[-L,0,-w],[-L,0,w],[0,h,w],[0,h,-w],[B,0,-w],[B,0,w]];
     const tri=(a,b,c,ua,ub,uc)=>({p:[P[a],P[b],P[c]],u:[ua,ub,uc]});
     const faces=[tri(0,1,2,[0,0],[0,1],[1,1]),tri(0,2,3,[0,0],[1,1],[1,0]),tri(3,2,5,[1,0],[1,1],[1,1]),tri(3,5,4,[1,0],[1,1],[1,0]),tri(0,3,4,[0,0],[0,0],[0,0]),tri(1,5,2,[0,0],[0,0],[0,0])];
     const pos=[],uv=[];for(const F of faces){for(const v of F.p)pos.push(...v);for(const u of F.u)uv.push(...u);}
     geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geo.computeVertexNormals();
     const m=new THREE.Mesh(geo,rm);m.position.set(T.x[f],0,T.y[f]);m.rotation.y=-Math.atan2(T.ty[f],T.tx[f]);m.castShadow=m.receiveShadow=true;scene.add(m);}
   for(const f of FEAT.bumps){const m=new THREE.Mesh(new THREE.CylinderGeometry(7,7,HW*2-2,20),side);m.rotation.x=Math.PI/2;m.rotation.order='YXZ';m.rotation.y=-Math.atan2(T.ty[f],T.tx[f]);m.scale.set(1,1,.55);m.position.set(T.x[f],-1,T.y[f]);m.castShadow=m.receiveShadow=true;
     m.material=std({color:'#b07a46',roughness:.95});scene.add(m);}}
  // water
  for(const z of FEAT.water){const m=new THREE.Mesh(new THREE.CircleGeometry(z.r,40),std({color:'#24527e',roughness:.08,metalness:.1,transparent:true,opacity:.9,envMapIntensity:.6}));
    m.rotation.x=-Math.PI/2;m.scale.set(1.12,.9,1);m.position.set(z.x,.35,z.y);m.receiveShadow=true;scene.add(m);}
  // grandstand along the top with a crowd, and bleachers on the left
  {const[c,g]=mkCanvas(512,64);g.fillStyle='#4a4650';g.fillRect(0,0,512,64);for(let k=0;k<1400;k++){g.fillStyle=`hsl(${hash(k,1)*360|0},55%,${40+hash(k,2)*35|0}%)`;g.fillRect(hash(k,3)*512,hash(k,4)*64,4,5);}
   const crowd=tex(c,true),seat=std({color:'#5a5660',roughness:.8});
   const stand=(len,x0,z0,rot)=>{const grp=new THREE.Group();for(let k=0;k<5;k++){const t2=crowd.clone();t2.needsUpdate=true;t2.repeat.set(len/120,1);
       const top=std({map:t2,roughness:.9});const b=new THREE.Mesh(new THREE.BoxGeometry(len,6+k*7,12),[seat,seat,top,seat,seat,seat]);b.position.set(len/2,(6+k*7)/2,-k*12);grp.add(b);}
     const roof=new THREE.Mesh(new THREE.BoxGeometry(len,1.5,40),std({color:'#e8e2d6',roughness:.6}));roof.position.set(len/2,70,-34);grp.add(roof);
     for(let x=0;x<=len;x+=len/6)box(1.6,70,1.6,MAT.dark,x,35,-56,grp);
     const trim=new THREE.Mesh(new THREE.BoxGeometry(len,3,1),std({color:'#d42a24'}));trim.position.set(len/2,68,-13.6);grp.add(trim);
     const bm=std({map:bannerTex(1024,140,3),roughness:.55});const nb=Math.max(1,Math.floor(len/300));
     for(let k=0;k<nb;k++){const bn=new THREE.Mesh(new THREE.PlaneGeometry(len/nb-30,(len/nb-30)*140/1024),bm);bn.position.set((k+.5)*len/nb,58,-12.8);grp.add(bn);}
     grp.position.set(x0,0,z0);grp.rotation.y=rot;shadowy(grp);scene.add(grp);};
   mats();stand(880,40,-6,0);stand(480,-6,540,Math.PI/2);}
  // billboards with the Trocas Mamalonas logo, and some with the game name
  {const mkBoard=kind=>{const[c,g]=mkCanvas(512,224);g.fillStyle=kind?'#d42a24':'#121010';g.fillRect(0,0,512,224);g.strokeStyle='#f2efe8';g.lineWidth=10;g.strokeRect(5,5,502,214);
      if(!kind){if(logosReady===2){const w=430,h=w*logoW.height/logoW.width;g.drawImage(logoW,256-w/2,112-h/2,w,h);}}
      else{g.fillStyle='#fff';g.font='900 96px Roboto Slab, Georgia, serif';g.textAlign='center';g.textBaseline='middle';g.fillText('OFF ROAD',256,104);g.font='700 30px Roboto Slab, Georgia, serif';g.fillText('STADIUM TRUCK RACING',256,180);}
      return tex(c);};
   const boards=[mkBoard(0),mkBoard(1)],post=std({color:'#3a3836',metalness:.4,roughness:.5});
   const place=(x,z,ry,k)=>{const grp=new THREE.Group();const face=new THREE.Mesh(new THREE.BoxGeometry(70,30,1.5),[post,post,post,post,std({map:boards[k],roughness:.5}),post]);face.position.y=30;grp.add(face);
     for(const px of [-26,26])box(2,16,2,post,px,8,0,grp);grp.position.set(x,0,z);grp.rotation.y=ry;shadowy(grp);scene.add(grp);};
   place(1000,140,-1.1,0);place(1000,330,-1.2,1);place(1000,520,-1.3,0);place(250,640,0,1);place(520,650,0,0);place(790,640,0,1);}
  // buildings outside the arena
  {const[c,g]=mkCanvas(128,128);g.fillStyle='#b9a58a';g.fillRect(0,0,128,128);for(let y=8;y<128;y+=24)for(let x=8;x<128;x+=20){g.fillStyle=hash(x,y)<.2?'#e8d8a0':'#3a3a42';g.fillRect(x,y,12,14);}
   const wt=tex(c,true),roofM=std({color:'#6e665c',roughness:.9});
   const B=[[1120,60,120,90,70],[1100,260,90,120,46],[1150,470,140,110,90],[1090,700,110,80,36],[-200,80,140,100,80],[-180,330,90,140,40],[-230,560,130,110,60],[200,780,180,90,44],[560,800,140,110,70],[880,780,120,90,52],[400,-260,200,90,90],[760,-250,160,110,60]];
   for(const [x,z,w,d,h] of B){const t2=wt.clone();t2.needsUpdate=true;t2.repeat.set(w/40,h/40);const m=std({map:t2,roughness:.85});const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),[m,m,roofM,roofM,m,m]);b.position.set(x,h/2,z);b.castShadow=b.receiveShadow=true;scene.add(b);
     if(hash(x,z)<.5){const tk=new THREE.Mesh(new THREE.CylinderGeometry(8,8,12,12),std({color:'#8a7a62'}));tk.position.set(x+w*.2,h+10,z);tk.castShadow=true;scene.add(tk);}}}
  // light towers in the corners
  for(const [x,z] of [[-20,-20],[980,-20],[-20,620],[980,620]]){const grp=new THREE.Group();box(3,130,3,MAT.dark,0,65,0,grp);const lamp=box(22,8,4,std({color:'#e8e2d6',emissive:'#fff6d0',emissiveIntensity:.5}),0,132,0,grp);lamp.lookAt(new THREE.Vector3(W/2-x,0,H/2-z).add(lamp.position));grp.position.set(x,0,z);shadowy(grp);scene.add(grp);}
  // tire stacks and barrels on the banks, kept away from other lanes
  {const tireGeo=new THREE.CylinderGeometry(4,4,2.6,14),inst=[],barrels=[];
   for(let i=0;i<T.n;i+=13){for(const s of [-1,1]){const o=s*(HW+14),x=T.x[i]+T.nx[i]*o,y=T.y[i]+T.ny[i]*o;if(x<10||x>W-10||y<10||y>H-10)continue;
       let ok=true;for(let j=0;j<T.n;j+=3){if(Math.abs(j-i)<20||Math.abs(j-i)>T.n-20)continue;if((T.x[j]-x)**2+(T.y[j]-y)**2<(HW+16)**2){ok=false;break;}}
       if(!ok||hash(i,s)<.45)continue;(hash(i,s+5)<.75?inst:barrels).push([x,y]);}}
   const im=new THREE.InstancedMesh(tireGeo,MAT.tire,inst.length*3);const mtx=new THREE.Matrix4();let n=0;
   for(const [x,y] of inst)for(let k=0;k<3;k++)im.setMatrixAt(n++,mtx.makeTranslation(x,7.5+k*2.7,y));im.castShadow=true;scene.add(im);
   const bm=[std({color:'#d42a24',roughness:.5,metalness:.3}),std({color:'#2a62d8',roughness:.5,metalness:.3})];
   barrels.forEach(([x,y],k)=>{const b=new THREE.Mesh(new THREE.CylinderGeometry(3,3,8,12),bm[k%2]);b.position.set(x,10,y);b.castShadow=true;scene.add(b);});}
  // start/finish arch: big TROCAS MAMALONAS banners on both sides, you drive under it every lap
  {const i=2,span=2*(HW+12),grp=new THREE.Group(),dark=std({color:'#1b1816',metalness:.5,roughness:.45}),ban=std({map:bannerTex(1024,140,3),roughness:.55});
   for(const sd of [-1,1]){const post=new THREE.Mesh(new THREE.BoxGeometry(4,52,4),dark);post.position.set(sd*span/2,26,0);grp.add(post);}
   const beam=new THREE.Mesh(new THREE.BoxGeometry(span+8,13,3),[dark,dark,dark,dark,ban,ban]);beam.position.y=46;grp.add(beam);
   const top=new THREE.Mesh(new THREE.BoxGeometry(span+10,1.6,4.4),std({color:'#d42a24'}));top.position.y=53.3;grp.add(top);
   grp.position.set(T.x[i],0,T.y[i]);grp.rotation.y=-Math.atan2(T.ny[i],T.nx[i]);shadowy(grp);scene.add(grp);
   // a big sign on top of the arch that faces the camera, so the logo reads from the stands
   const sign=new THREE.Group(),face=std({map:bannerTex(640,292,1),roughness:.5}),back=std({map:bannerTex(640,292,1),roughness:.5});
   const bd=new THREE.Mesh(new THREE.BoxGeometry(84,38,2.4),[dark,dark,dark,dark,face,back]);bd.position.y=75;sign.add(bd);
   const rim=new THREE.Mesh(new THREE.BoxGeometry(88,42,1.6),std({color:'#d42a24'}));rim.position.y=75;sign.add(rim);
   const mast=new THREE.Mesh(new THREE.BoxGeometry(3,6,3),dark);mast.position.y=56;sign.add(mast);
   sign.position.set(T.x[i],0,T.y[i]);shadowy(sign);scene.add(sign);}
  // two giant jumbotron boards in the infield, right beside the track, facing the camera
  {const frame=std({color:'#1b1816',metalness:.5,roughness:.45});
   const jumbo=(x,z,w)=>{const h=w*.44,grp=new THREE.Group(),screen=std({map:bannerTex(768,338,1),roughness:.5,emissive:'#222222'});
     const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,3),[frame,frame,frame,frame,screen,frame]);b.position.y=16+h/2;grp.add(b);
     const rim=new THREE.Mesh(new THREE.BoxGeometry(w+4,h+4,2),std({color:'#d42a24'}));rim.position.set(0,16+h/2,-1.4);grp.add(rim);
     for(const px of [-w*.32,w*.32]){const p=new THREE.Mesh(new THREE.BoxGeometry(3,16,3),frame);p.position.set(px,8,0);grp.add(p);}
     grp.position.set(x,0,z);shadowy(grp);scene.add(grp);};
   jumbo(285,450,150);jumbo(204,345,92);}
  {const i=0,x=T.x[i]-T.nx[i]*(HW+24),y=T.y[i]-T.ny[i]*(HW+24);flagman=new THREE.Group();
   box(2.4,6,2,std({color:'#1d2632'}),0,3,0,flagman);box(4,6,2.6,MAT.white,0,9,0,flagman);const head=new THREE.Mesh(new THREE.SphereGeometry(1.7,10,8),std({color:'#e0b08a'}));head.position.y=13.6;flagman.add(head);
   const arm=new THREE.Group();arm.position.set(1.6,11,0);flagman.add(arm);box(1,8,1,std({color:'#ddd'}),0,4,0,arm);
   const flag=new THREE.Mesh(new THREE.PlaneGeometry(7,5),new THREE.MeshStandardMaterial({color:'#2fbf4a',side:THREE.DoubleSide}));flag.position.set(3.5,7,0);arm.add(flag);
   flagman.userData={arm,flag};flagman.position.set(x,9,y);shadowy(flagman);scene.add(flagman);}
}

/* ---------- particles: dust, mud, splashes, sparks ---------- */
const PMAX=isTouch?260:420;
function buildParticles(){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(PMAX*3),3));
  g.setAttribute('color',new THREE.Float32BufferAttribute(new Float32Array(PMAX*4),4));g.setAttribute('size',new THREE.Float32BufferAttribute(new Float32Array(PMAX),1));
  const m=new THREE.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{scale:{value:600}},
    vertexShader:'attribute float size;attribute vec4 color;varying vec4 vC;uniform float scale;void main(){vC=color;vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=size*scale/-mv.z;gl_Position=projectionMatrix*mv;}',
    fragmentShader:'varying vec4 vC;void main(){vec2 d=gl_PointCoord-.5;float r=dot(d,d)*4.;if(r>1.)discard;gl_FragColor=vec4(vC.rgb,vC.a*(1.-r));}'});
  pts=new THREE.Points(g,m);pts.frustumCulled=false;scene.add(pts);}
const PCOL={fire:[1,.5,.12],dust:[.82,.66,.46],mud:[.3,.18,.08],water:[.75,.86,1],spark:[1,.9,.55]};
function syncParticles(){const P=pts.geometry.attributes.position.array,C=pts.geometry.attributes.color.array,S=pts.geometry.attributes.size.array;let n=0;
  for(const p of parts){if(n>=PMAX)break;const k=p.life/p.max,c=PCOL[p.kind];P[n*3]=p.x;P[n*3+1]=p.h;P[n*3+2]=p.y;C[n*4]=c[0];C[n*4+1]=c[1];C[n*4+2]=c[2];
    C[n*4+3]=p.kind==='dust'?.55*k:p.kind==='spark'||p.kind==='fire'?k:.85*k;S[n]=p.kind==='dust'?6+(1-k)*16:p.kind==='fire'?3+k*5:p.kind==='spark'?2.4:p.kind==='mud'?3.4:3;n++;}
  for(let i=n;i<PMAX;i++){S[i]=0;C[i*4+3]=0;}
  pts.geometry.setDrawRange(0,n);pts.geometry.attributes.position.needsUpdate=pts.geometry.attributes.color.needsUpdate=pts.geometry.attributes.size.needsUpdate=true;}

/* ---------- start-up ---------- */
function init3D(){
  R3=new THREE.WebGLRenderer({canvas:cv,antialias:!isTouch,powerPreference:'high-performance'});
  R3.setPixelRatio(Math.min(devicePixelRatio||1,isTouch?1.5:2));R3.outputEncoding=THREE.sRGBEncoding;R3.toneMapping=THREE.ACESFilmicToneMapping;R3.toneMappingExposure=.92;
  R3.shadowMap.enabled=true;R3.shadowMap.type=THREE.PCFSoftShadowMap;
  scene=new THREE.Scene();scene.background=new THREE.Color('#e3c79f');scene.fog=new THREE.Fog('#e3c79f',900,2200);
  cam=new THREE.PerspectiveCamera(40,1,5,5000);
  // soft sky reflections for the paint and chrome
  {const env=new THREE.Scene();const sky=new THREE.Mesh(new THREE.SphereGeometry(100,24,16),new THREE.ShaderMaterial({side:THREE.BackSide,
     vertexShader:'varying vec3 p;void main(){p=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
     fragmentShader:'varying vec3 p;void main(){float h=normalize(p).y;vec3 c=mix(vec3(.55,.42,.3),vec3(.75,.85,1.),smoothstep(-.2,.6,h));c+=vec3(1.,.95,.8)*pow(max(0.,dot(normalize(p),normalize(vec3(-.4,.8,-.5)))),40.)*4.;gl_FragColor=vec4(c,1.);}'}));
   env.add(sky);const pm=new THREE.PMREMGenerator(R3);envTex=pm.fromScene(env).texture;scene.environment=envTex;}
  scene.add(new THREE.HemisphereLight('#fff4e0','#6a4428',.5));
  sun=new THREE.DirectionalLight('#fff0d6',1.9);sun.castShadow=true;const sm=isTouch?1024:2048;sun.shadow.mapSize.set(sm,sm);
  const sc=sun.shadow.camera;sc.left=-340;sc.right=340;sc.top=340;sc.bottom=-340;sc.near=10;sc.far=1400;sun.shadow.bias=-.0006;sun.shadow.normalBias=.6;
  scene.add(sun);scene.add(sun.target);
  mats();buildArena();buildParticles();
  arrow=new THREE.Mesh(new THREE.ConeGeometry(3.2,7,4),new THREE.MeshBasicMaterial({color:'#ffffff'}));arrow.rotation.x=Math.PI;scene.add(arrow);
}
function rebuildGround(){if(!groundMat)return;groundMat.map.dispose();groundMat.map=tex(paintGround());groundMat.map.anisotropy=Math.min(8,R3.capabilities.getMaxAnisotropy());groundMat.needsUpdate=true;}

/* ---------- each truck gets a 3D model; keep them in step with the physics ---------- */
function syncVehicles(){for(const t of trucks){if(!t.mesh){t.mesh=buildVehicle(t.model,COLORS[t.c][1]);scene.add(t.mesh.root);}}
  scene.children.filter(o=>o.userData.vehicle&&!trucks.some(t=>t.mesh&&t.mesh.root===o)).forEach(o=>scene.remove(o));
  for(const t of trucks)t.mesh.root.userData.vehicle=true;}
let camPos=null,camLook=null,orbitA=0;
function snapCam(){camPos=null;}
// a truck's drawn position: blended between its last two physics steps so motion is smooth at any frame rate
function ipos(t,a){if(t.px===undefined)return{x:t.x,y:t.y,h:t.z+t.lift,ang:t.ang};return{x:t.px+(t.x-t.px)*a,y:t.py+(t.y-t.py)*a,h:t.pz+(t.z+t.lift-t.pz)*a,ang:t.pa+angDiff(t.ang,t.pa)*a};}
function setLevel(V,lv){if(V.level===lv)return;V.level=lv;
  for(const w of V.wheels){const k=lv>=1?1.6:1;w.piv.scale.setScalar(k);w.piv.position.z=w.z0*(lv>=1?1.12:1);}
  if(lv>=2){for(const m of [V.paint,V.accent]){m.color.set(m===V.paint?'#b8780a':'#704806');m.metalness=.55;m.roughness=.3;m.envMapIntensity=1;m.emissive.set('#2a1600');m.emissiveIntensity=.2;}V.fire.visible=true;if(V.decal)V.decal.material.map=logoTex(true);V.decal.material.needsUpdate=true;}}
function render3D(dt,alpha=1){
  if(!R3)return;syncVehicles();const time=performance.now()/1000,ease=k=>1-Math.pow(1-k,dt*60);
  for(const t of trucks){const V=t.mesh,g=V.root,P=ipos(t,alpha);g.position.set(P.x,P.h,P.y);g.rotation.y=-P.ang;
    setLevel(V,t.gold>=10?2:t.gold>=5?1:0);const big=V.level>=1;
    const fx=Math.cos(t.ang),fy=Math.sin(t.ang),vf=t.vx*fx+t.vy*fy,vl=-t.vx*fy+t.vy*fx;
    // body leans in turns; after a crash it jolts sideways for a moment
    const jolt=(t.jolt||0)*(t.joltSide||1)*.32*Math.cos((1-(t.jolt||0))*9);
    V.body.rotation.z=t.pitch*.85;V.roll=(V.roll||0)+((t.z>0?0:clamp(vl*.07,-.12,.12))-(V.roll||0))*ease(.2);V.body.rotation.x=V.roll+jolt;
    // a gentle suspension ripple tied to the wheels turning (not the clock), so it never buzzes
    const ripple=t.z>0?.4:Math.sin(t.wheel*.9+t.c)*Math.min(.12,Math.abs(vf)*.03);V.body.position.y=(big?V.wheels[0].r*.62:0)+ripple;
    for(const w of V.wheels){const k=big?1.6:1;w.spin.rotation.z-=vf/(w.r*k)*(dt*60);if(w.front)w.piv.rotation.y=-(t.input.steer||0)*.42;w.piv.position.y=w.r*k+(t.z>0?-1.2:0);}
    if(V.level>=2)for(const f of V.fire.children)if(f.geometry.type==='ConeGeometry')f.scale.set(1,.75+Math.random()*.5,1);
    V.flame.visible=t.nitroT>0;if(V.flame.visible)V.flame.scale.set(1,.7+Math.random()*.6,1);}
  // pickups: spinning nitro bottles and money bags
  for(const P of pickups)if(!pickupMeshes.has(P)){const grp=new THREE.Group();
    if(P.kind==='nitro'){const b=new THREE.Mesh(new THREE.CylinderGeometry(2.6,2.6,9,14),std({color:'#2f62d8',metalness:.6,roughness:.25}));b.position.y=4.5;grp.add(b);const cap=new THREE.Mesh(new THREE.CylinderGeometry(1.2,1.4,2.4,10),MAT.chrome);cap.position.y=10;grp.add(cap);}
    else{const b=new THREE.Mesh(new THREE.SphereGeometry(4.4,14,10),std({color:'#d9b45a',roughness:.85}));b.scale.y=.85;b.position.y=4;grp.add(b);const k=new THREE.Mesh(new THREE.CylinderGeometry(1,1.6,2.4,8),std({color:'#a07a28'}));k.position.y=8.4;grp.add(k);
      const[c,g]=mkCanvas(64,64);g.fillStyle='#2e7a2e';g.font='900 52px Roboto Slab, Georgia, serif';g.textAlign='center';g.textBaseline='middle';g.fillText('$',32,36);const s=new THREE.Sprite(new THREE.SpriteMaterial({map:tex(c),depthTest:false}));s.scale.set(6,6,1);s.position.y=4.4;grp.add(s);}
    shadowy(grp);grp.position.set(P.x,1,P.y);scene.add(grp);pickupMeshes.set(P,grp);}
  for(const [P,grp] of pickupMeshes){if(!pickups.includes(P)){scene.remove(grp);pickupMeshes.delete(P);continue;}grp.rotation.y=time*2;grp.position.y=1+Math.sin(time*3+P.x)*1.2;}
  // gold Trocas coins: standing up, spinning, with the logo on both faces
  for(const C of coins)if(!coinMeshes.has(C)){const grp=new THREE.Group(),m=new THREE.Mesh(coinGeo(),coinMats());m.rotation.x=Math.PI/2;m.position.y=12.5;m.castShadow=true;grp.add(m);grp.position.set(C.x,0,C.y);scene.add(grp);coinMeshes.set(C,grp);}
  for(const [C,grp] of coinMeshes){if(!coins.includes(C)){scene.remove(grp);coinMeshes.delete(C);continue;}grp.rotation.y=time*2.4+C.x;grp.position.y=Math.sin(time*3+C.y)*1.2;}
  // flagman waves at the start, on the final lap (white flag) and at the finish (checkered: shown as black and white)
  if(flagman){const u=flagman.userData,wave=state==='count'||(state==='race'&&raceT<70)||(me&&me.finished)||(me&&me.lap===laps-1&&state==='race');
    u.arm.rotation.z=wave?Math.sin(time*9)*.7-.4:-.15;u.flag.material.color.set(me&&me.finished?(Math.floor(time*6)%2?'#111':'#fff'):me&&me.lap===laps-1?'#ffffff':'#2fbf4a');}
  if(frameN%20===0)marksTex.needsUpdate=true;
  syncParticles();
  // camera: follow your truck from up and behind, like a TV camera in the stands
  const narrow=cv.clientWidth<cv.clientHeight;let focus,wantPos;
  const MP=me?ipos(me,alpha):null;
  if(me&&(state==='race'||state==='count')){const lead=narrow?14:22;focus=new THREE.Vector3(MP.x+me.vx*lead,0,MP.y+me.vy*lead*.7);
    wantPos=focus.clone().add(narrow?new THREE.Vector3(0,330,250):new THREE.Vector3(0,250,205));}
  else{orbitA+=dt*.06;focus=new THREE.Vector3(W/2,0,H/2+20);wantPos=focus.clone().add(new THREE.Vector3(Math.sin(orbitA)*520,560,Math.cos(orbitA)*520+180));}
  if(!camPos){camPos=wantPos.clone();camLook=focus.clone();}
  const k=ease(state==='race'||state==='count'?.09:.03);camPos.lerp(wantPos,k);camLook.lerp(focus,k);
  cam.position.copy(camPos);if(shake>.3){cam.position.x+=(Math.random()-.5)*shake;cam.position.y+=(Math.random()-.5)*shake;}cam.lookAt(camLook);
  sun.target.position.copy(camLook);sun.position.copy(camLook).add(new THREE.Vector3(-260,520,-300));
  if(me&&state!=='done'&&state!=='menu'){arrow.visible=true;arrow.position.set(MP.x,MP.h+(me.gold>=5?40:32)+Math.sin(time*5)*2,MP.y);}else arrow.visible=false;
  R3.render(scene,cam);
}

/* ---------- menu pictures of each vehicle ---------- */
let thumbR=null;
function thumbs(colorHex){
  if(!thumbR){thumbR=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});thumbR.setSize(240,170);thumbR.outputEncoding=THREE.sRGBEncoding;thumbR.toneMapping=THREE.ACESFilmicToneMapping;thumbR.shadowMap.enabled=true;}
  const s=new THREE.Scene();s.environment=envTex;s.add(new THREE.HemisphereLight('#fff4e0','#7a5230',.7));const l=new THREE.DirectionalLight('#fff0d6',1.4);l.position.set(-30,60,-20);l.castShadow=true;l.shadow.mapSize.set(512,512);
  const lc=l.shadow.camera;lc.left=lc.bottom=-40;lc.right=lc.top=40;s.add(l);
  const fl=new THREE.Mesh(new THREE.CircleGeometry(40,32),std({color:'#9a6438',roughness:1}));fl.rotation.x=-Math.PI/2;fl.receiveShadow=true;s.add(fl);
  const c=new THREE.PerspectiveCamera(32,240/170,1,500);c.position.set(30,30,46);c.lookAt(0,5,0);const out=[];
  for(const [m] of MODELS){const v=buildVehicle(m,colorHex);v.root.rotation.y=-.5;s.add(v.root);thumbR.render(s,c);out.push(thumbR.domElement.toDataURL());s.remove(v.root);}
  return out;}
const PAL=COLORS.map(([name,hex])=>({name,top:hex}));
